package com.filehider.File_Hider;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FileHiderApplication {

	public static void main(String[] args) {
		SpringApplication.run(FileHiderApplication.class, args);
	}

}
