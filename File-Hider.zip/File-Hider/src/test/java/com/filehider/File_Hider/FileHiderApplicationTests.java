package com.filehider.File_Hider;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FileHiderApplicationTests {

	@Test
	void contextLoads() {
	}

}
