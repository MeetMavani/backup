import "./Main.css";
import { useEffect, useState } from "react";
import gsap from "gsap";

const Main = () => {
  const [array, setArray] = useState([]);

  useEffect(() => {
    resetArray();
  }, []);

  const resetArray = () => {
    const newArray = Array.from({ length: 5 }, () => Math.floor(Math.random() * 100));
    setArray(newArray);
  };

  const timeline = gsap.timeline({ repeat: 0 });
  timeline.pause();

  // Swap animation function that adds animations to the timeline
  function SwapAnimation(index1, index2) {
    timeline.to(`.element${index1}`, {
      y: 60,
      duration: 1,
      ease: "back"
    });
  
    timeline.to(`.element${index1}`, {
      x: 45.5,
      duration: 1,
      ease: "back"
    });
  
    timeline.to(`.element${index2}`, {
      x: -45,
      ease: "back",
      duration: 1
    });
  
    timeline.to(`.element${index1}`, {
      y: 0,
      duration: 1,
      ease: "back"
    });
  }

  // Bubble sort logic that uses the SwapAnimation function
  const bubbleSort = () => {
    for (let i = 0; i < array.length - 1; i++) {
      for (let j = 0; j < array.length - i - 1; j++) {
        if (array[j] > array[j + 1]) {
          // Swap array values
          const temp = array[j];
          array[j] = array[j + 1];
          array[j + 1] = temp;
          
          // Trigger the swap animation
          SwapAnimation(j, j + 1);
        }
      }
    }
    console.log(array);
  };

  return (
    <div id="array">
      {array.map((value, index) => (
        <div key={index} className={`element${index}`}>{value}</div>
      ))}

      <button onClick={() => {
        bubbleSort();
        timeline.play();
      }}>BubbleSort</button>
    </div>
  );
};

export default Main;
