import { useState, useRef } from 'react';

const ImageSorter = () => {
  const [imageLoaded, setImageLoaded] = useState(false);
  const [isSorting, setIsSorting] = useState(false);
  const canvasRef = useRef(null);

  // Load and display the image on the canvas, resizing to 100x100 pixels
  const loadImage = (event) => {
    const img = new Image();
    img.src = URL.createObjectURL(event.target.files[0]);
    img.onload = () => {
      const canvas = canvasRef.current;
      const ctx = canvas.getContext('2d');
      canvas.width = 100;
      canvas.height = 100;
      ctx.drawImage(img, 0, 0, 100, 100); // Resize to 100x100 pixels
      setImageLoaded(true); // Set image loaded state to true
    };
  };

  // Extract pixel data from the canvas
  const getPixelData = () => {
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
    return imageData.data;
  };

  // Bubble sort the pixel data by grayscale value in chunks
  const bubbleSortPixelsChunked = (pixels, chunkSize = 100) => {
    const sortedPixels = [...pixels];
    let i = 0;

    const processChunk = () => {
      for (let c = 0; c < chunkSize && i < sortedPixels.length; i += 4, c++) {
        for (let j = 0; j < sortedPixels.length - i - 4; j += 4) {
          const [r1, g1, b1] = [sortedPixels[j], sortedPixels[j + 1], sortedPixels[j + 2]];
          const [r2, g2, b2] = [sortedPixels[j + 4], sortedPixels[j + 5], sortedPixels[j + 6]];
          if (r1 + g1 + b1 > r2 + g2 + b2) {
            for (let k = 0; k < 4; k++) {
              [sortedPixels[j + k], sortedPixels[j + 4 + k]] = [sortedPixels[j + 4 + k], sortedPixels[j + k]];
            }
          }
        }
      }

      if (i < sortedPixels.length) {
        setTimeout(processChunk, 0); // Schedule next chunk
      } else {
        updateCanvas(sortedPixels);
        setIsSorting(false); // Sorting is done
      }
    };

    processChunk(); // Start the first chunk
  };

  // Update the canvas with the sorted pixel data
  const updateCanvas = (sortedPixels) => {
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    const imageData = ctx.createImageData(canvas.width, canvas.height);
    imageData.data.set(sortedPixels);
    ctx.putImageData(imageData, 0, 0);
  };

  // Handle sorting the image
  const handleSort = () => {
    if (isSorting) return; // Prevent multiple clicks
    setIsSorting(true);
    const pixels = getPixelData();
    bubbleSortPixelsChunked(pixels);
  };

  return (
    <div>
      <h1>Image Sorting Visualizer</h1>
      <input type="file" accept="image/*" onChange={loadImage} />
      <br />
      <canvas ref={canvasRef} style={{ border: '1px solid black', marginTop: '10px' }}></canvas>
      <br />
      {imageLoaded && (
        <button onClick={handleSort} style={{ marginTop: '10px' }} disabled={isSorting}>
          {isSorting ? 'Sorting...' : 'Sort Image'}
        </button>
      )}
    </div>
  );
};

export default ImageSorter;
