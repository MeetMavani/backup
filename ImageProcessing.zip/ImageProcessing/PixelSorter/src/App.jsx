import ImageSorter from "../Components/ImageSorter"

const App = () => {

  return (
    <>
      <ImageSorter />
    </>
  )
}

export default App
