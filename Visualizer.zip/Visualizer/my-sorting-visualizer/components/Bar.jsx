import  { useState, useEffect } from 'react';
import './Bar.css';

const SortingVisualizer = () => {
  const [array, setArray] = useState([]);

  useEffect(() => {
    resetArray();
  }, []);

  const resetArray = () => {
    const newArray = Array.from({ length: 20 }, () => Math.floor(Math.random() * 300));
    setArray(newArray);
  };

  const bubbleSort = async () => {
    let arr = array.slice();
    for (let i = 0; i < arr.length - 1; i++) {
      for (let j = 0; j < arr.length - i - 1; j++) {
        if (arr[j] > arr[j + 1]) {
          [arr[j], arr[j + 1]] = [arr[j + 1], arr[j]];
          setArray([...arr]);
          await new Promise((resolve) => setTimeout(resolve, 100));
        }
      }
    }
  };

  return (
    <div className="array-container">
      {array.map((value, idx) => (
        <div
          className="array-bar"
          key={idx}
          style={{ height: `${value}px` }}
        ><p>{value}</p></div>
      ))}
      <div id='buttondiv'>
        <button onClick={resetArray}>Generate New Array</button>
        <br />
        <button onClick={bubbleSort}>Bubble Sort</button>
      </div>
    </div>
  );
};

export default SortingVisualizer;
