import "./Main.css";
import { useGSAP } from "@gsap/react"
import gsap from "gsap";

const Main = () => {
  const arr = [22, 15, 11, 4, 8, 2, 18]

  const timeline = gsap.timeline({ repeat: 0})
  timeline.pause();

  // element 1: Y(0 => 60), X(0 => 45.5), Y(60 => 0)     element 2: (0 => -45)  

  function SwapAnimation(index1, index2) {
    let diff = index2 - index1;
    let YAxisDistance = diff * 60;
    let XAxisDistance = diff * 45;

    useGSAP(() => {                                              
      timeline.to(`.element${index1}`, {
        y: YAxisDistance,
        duration: 1,
        ease: "back"
      });
  
      timeline.to(`.element${index1}`, {
        x: XAxisDistance,
        duration: 1,
        ease: "back"
      });
  
      timeline.to(`.element${index2}`, {
        x: -XAxisDistance,
        ease: "back", 
        duration: 1
      })
  
      timeline.to(`.element${index1}`, {
        y: 0,
        duration: 1, 
        ease: "back"
      });
      
    }, [])
    
  }


  for (let i = 0; i < arr.length; i++) {
    for (let j = 0; j < arr.length - i - 1; j++) {
      if (arr[j] > arr[j + 1]) {
        [arr[j], arr[j + 1]] = [arr[j + 1], arr[j]];
        SwapAnimation(j, j+1)
      }
    }
  }


  return (
    <div id="array">
      <div className="element0">{arr[0]}</div>
      <div className="element1">{arr[1]}</div>
      <div className="element2">{arr[2]}</div>
      <div className="element3">{arr[3]}</div>
      <div className="element4">{arr[4]}</div>
      <div className="element5">{arr[5]}</div>
      <div className="element6">{arr[6]}</div>

      <button onClick={() => {timeline.play()}}>Swap</button>
    </div>
  )
}

export default Main