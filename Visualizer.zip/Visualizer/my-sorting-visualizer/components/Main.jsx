import "./Main.css";
import { useGSAP } from "@gsap/react"
import gsap from "gsap";
import { useEffect, useState } from "react";

const Main = () => {
  const [array, setArray] = useState([]);

  useEffect(() => {
    resetArray();
  }, []);

  const resetArray = () => {
    const newArray = Array.from({length: 5}, () => Math.floor(Math.random() * 100));
    setArray(newArray)
  }

  const timeline = gsap.timeline({ repeat: 0})
  timeline.pause();

  // element 1: Y(0 => 60), X(0 => 45.5), Y(60 => 0)     element 2: (0 => -45)  

  function SwapAnimation(index1, index2) {

    useGSAP(() => {                                              
      timeline.to(`.element${index1}`, {
        y: 60,
        duration: 1,
        ease: "back"
      });
  
      timeline.to(`.element${index1}`, {
        x: 45.5,
        duration: 1,
        ease: "back"
      });
  
      timeline.to(`.element${index2}`, {
        x: -45,
        ease: "back", 
        duration: 1
      })
  
      timeline.to(`.element${index1}`, {
        y: 0,
        duration: 1, 
        ease: "back"
      });
      
    }, [])
    
  }


  for (let i = 0; i < array.length - 1; i++) {
    for (let j = 0; j < array.length - i - 1; j++) {
      if (array[j] > array[j + 1]) {
        // [arr[j], arr[j + 1]] = [arr[j + 1], arr[j]];
        SwapAnimation(j, j+1)
        
      }
    }
    console.log(array);
  }


  return (
    <div id="array">
      {array.map((value, index) => (
        <div key={index} className={`element${index}`}>{value}</div>
      ))}

      <button onClick={() => {timeline.play()}}>BubbleSort</button>
    </div>
  )
}

export default Main