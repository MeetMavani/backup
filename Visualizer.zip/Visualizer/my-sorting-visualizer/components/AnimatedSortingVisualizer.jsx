import { useState, useEffect, useRef } from 'react';
import gsap from 'gsap';
// import './AnimatedSortingVisualizer.css';

const SortingVisualizer = () => {
  const [array, setArray] = useState([]);
  const buttonRefs = useRef([]);

  useEffect(() => {
    resetArray();
  }, []);

  const resetArray = () => {
    const newArray = Array.from({ length: 10 }, () => Math.floor(Math.random() * 100));
    setArray(newArray);
    buttonRefs.current = [];
  };

  const bubbleSort = async () => {
    let arr = array.slice();
    for (let i = 0; i < arr.length - 1; i++) {
      for (let j = 0; j < arr.length - i - 1; j++) {
        if (arr[j] > arr[j + 1]) {
          await swap(j, j + 1);
          [arr[j], arr[j + 1]] = [arr[j + 1], arr[j]];
          setArray([...arr]);
        }
      }
    }
  };

  const swap = async (i, j) => {
    const buttons = buttonRefs.current;
    const button1 = buttons[i];
    const button2 = buttons[j];

    const button1Rect = button1.getBoundingClientRect();
    const button2Rect = button2.getBoundingClientRect();

    const deltaX = button2Rect.left - button1Rect.left;

    const tl = gsap.timeline();
    tl.to(button1, { x: deltaX, duration: 2 }) // Increased duration to 0.6s
      .to(button2, { x: -deltaX, duration: 2 }, "<");

    await tl.then(); // Ensures the swap function waits for the animation to complete

    // Update the refs array to reflect the new positions
    [buttonRefs.current[i], buttonRefs.current[j]] = [buttonRefs.current[j], buttonRefs.current[i]];

    // Reset the transforms to zero after swapping
    gsap.set(button1, { x: 0 });
    gsap.set(button2, { x: 0 });
  };

  return (
    <div className="array-container">
      {array.map((value, idx) => (
        <button
          key={idx}
          className="array-button"
          ref={(el) => (buttonRefs.current[idx] = el)}
          style={{ left: `${idx * 60}px` }}
        >
          {value}
        </button>
      ))}
      <button onClick={resetArray}>Generate New Array</button>
      <button onClick={bubbleSort}>Bubble Sort</button>
    </div>
  );
};

export default SortingVisualizer;
