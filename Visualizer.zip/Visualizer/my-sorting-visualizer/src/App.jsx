// import Bar from '../components/Bar';
import Main from '../components/Main';
import './App.css';
// import AnimatedSortingVisualizer from '../components/AnimatedSortingVisualizer'

function App() {
  return (
    <>
      {/* <AnimatedSortingVisualizer /> */}
      {/* <div className="App">
        <Bar />
      </div> */}
      <div id='main'>
        <Main />
      </div>

    </>
  );
}

export default App;
