-- SELECT order_id, first_name, last_name
-- FROM orders
-- JOIN customers 
-- 	ON orders.customer_id = customers.customer_id
    

-- how to tackle with displaying common columns from different tables   
-- SELECT order_id, orders.customer_id, first_name, last_name
-- FROM orders
-- JOIN customers 
-- 	ON orders.customer_id = customers.customer_id


-- how to use alias 
-- SELECT order_id, o.customer_id, first_name, last_name
-- FROM orders o
-- JOIN customers c
-- 	ON o.customer_id = c.customer_id
    
-- Exeercise
SELECT order_id, o.product_id, p.name, quantity, o.unit_price
FROM order_items o 
JOIN products p 
	ON o.product_id = p.product_id