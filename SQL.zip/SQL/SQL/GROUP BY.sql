SELECT * FROM sql_store.orders;

SELECT sh.name, count(*)
FROM orders o
INNER JOIN shippers sh
	ON o.shipper_id = sh.shipper_id
GROUP BY sh.name
HAVING count(*) > 1