-- Comparision ops which can be used with WHERE clause
-- >
-- >=
-- <
-- <=
-- =
-- !=
-- <>


-- SELECT *
-- FROM customers
-- WHERE points > 3000;


-- SELECT *
-- FROM customers
-- -- WHERE state <> 'va'
-- WHERE birth_date > '1990-01-01'