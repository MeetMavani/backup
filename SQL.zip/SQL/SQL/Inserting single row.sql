INSERT INTO customers 
VALUES (DEFAULT,
 'Meet',
 'Mavani',
 NULL,
 NULL,
 'GADITAL',
 'PUNE',
 'MH',
 2000)