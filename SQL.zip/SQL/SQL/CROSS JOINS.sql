SELECT 
	c.first_name,
    p.name AS product
FROM customers c 
CROSS JOIN products p
ORDER BY first_name;


SELECT *
FROM shippers
CROSS JOIN products;

SELECT *
FROM shippers, products;
