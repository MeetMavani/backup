INSERT INTO shippers (name)
VALUES ('SH1'),
	   ('SH2'),
       ('SH3')