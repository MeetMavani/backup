-- SELECT * 
-- FROM customers
-- WHERE points BETWEEN 1000 AND 3000 

SELECT * 
FROM customers
WHERE birth_date BETWEEN '1990-1-1' AND '2000-1-1'