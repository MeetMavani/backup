-- SELECT *
-- FROM customers
-- WHERE last_name LIKE 'B%' 
-- WHERE last_name LIKE '%B%'
-- WHERE last_name LIKE '%y'
-- WHERE first_name LIKE 'b____a'

-- % for any number of characters
-- _ for single character


SELECT * 
FROM customers
WHERE address LIKE '%TRAIL%' OR 
	  address LIKE '%AVENUE%';

SELECT * 
FROM customers
WHERE phone lIKE '%9'