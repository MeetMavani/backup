import './App.css'
import Page1 from '../components/page1'
import Page2 from '../components/Page2'

function App() {


  return (
    <div>
      <Page1 />
      <Page2 />
    </div>
  )
}

export default App
