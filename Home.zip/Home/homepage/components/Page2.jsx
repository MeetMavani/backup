
function Page2() {
  return (
    <div 
    style={{
        width: "100%",
        height: "100vh",
        backgroundColor: "blue",
    }}>Page2</div>
  )
}

export default Page2