import { gsap } from "gsap";
import { useEffect, useRef, useState } from "react";
import '../src/App.css'


const Page1 = () => {

  const pageRef = useRef(null);  // For the curtain
  const letterD = useRef(null);  // For letter D
  const letterA = useRef(null);  // For letter A
  const letterS = useRef(null);  // For letter S
  const letterV = useRef(null);  // For letter V

  useEffect(() => {
    // Step 1: Show letters D, A, S, V
    gsap.to([letterD.current, letterA.current], {
      opacity: 1,
      top: "-17%",
      duration: 0.7,
      stagger: 0.2,
      delay: 0.6
    });

    gsap.to([letterS.current, letterV.current], {
       zIndex:98
    });

    gsap.to([letterS.current, letterV.current], {
      opacity: 1,
      top: "35%",
      duration: 0.6,
      stagger: 0.2 , 
      delay: 0.9, 
    });

    gsap.to('.blocks', {
      opacity:0,
      delay: 1.5  
    })

    // Step 2: Curtain effect (move up)
    gsap.to(pageRef.current, {
      clipPath: "inset(0% 0% 0% 0%)", // Reveal the screen by moving the curtain up
      duration: 0.6,
      delay: 2, // Delay until letters are fully visible
    });

    // // Step 3: Position letters S and V in their final spots
    gsap.to([letterS.current, letterV.current], {
      y: -360, // Move S upwards
      color: 'black',
      duration: 0.3,
      delay: 2.2, // Wait until the curtain starts moving
    });

  }, []);


  return (
    <div>
      {/* Curtain that starts covering the screen */}
      <div className="blocks"
        style={{
          position: "absolute",
          zIndex: 97,
          top: "340px",
          width: "100%",
          height: "312px",
          backgroundColor: "#242424",
        }}></div>
        <div className="blocks"
        style={{
          position: "absolute",
          zIndex: 99,
          top: "695px",
          width: "100%",
          height: "300px",
          backgroundColor: "red",
        }}></div> 

      <div
        ref={pageRef}
        style={{
          width: "100%",
          height: "100vh",
          backgroundColor: "white",
          position: "absolute",
          top: 0,
          left: 0,
          clipPath: "inset(100% 0% 0% 0%)", // Initially covers the screen
        }}
      ></div>
      
      {/* Letters */}
      <div
        ref={letterD}
        style={{
          color:"rgb(229, 219, 219)",
          position: "absolute",       
          top: "30%", //-10 //"-20%", 
          left: "12%", //12 //"12%",   
          fontSize: "24rem", //"28rem",  
          opacity: 0, 
        }}
      >
        D
      </div>

      <div
        ref={letterA}
        style={{
          color:"rgb(229, 219, 219)",
          position: "absolute",
          top: "30%", //-10  //top: "-20%",
          left: "50%", //50 //left: "52%",
          fontSize: "24rem", //fontSize: "28rem",
          opacity: 0, 
        }}
      >
        A
      </div>

      <div
        ref={letterS}
        style={{
          color:"rgb(229, 219, 219)",
          position: "absolute",
          top: "76%", //35 //top: "20%",
          left: "31%", //31 //left: "33%",
          fontSize: "24rem",//fontSize: "28rem",
          opacity: 0, 
        }}
      >
        S
      </div>

      <div
        ref={letterV}
        style={{
          color:"rgb(229, 219, 219)",
          position: "absolute",
          top: "76%", //35 //top: "20%", 
          left: "72%", // 72 //left: "69%",
          fontSize: "24rem", //fontSize: "28rem",
          opacity: 0, 
        }}
      >
        V
      </div>
    </div>
  )
}

export default Page1